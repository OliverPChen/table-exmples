## Dev

```
npm install
npm run dev
```

## Test

```
npm test
```
