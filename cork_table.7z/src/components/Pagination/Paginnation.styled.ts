import styled ,{css} from 'styled-components';

export  const PaginationContainer = styled.div`
   height:5rem;
   display:flex;
   display: flex;
   align-items: flex-end;
    justify-content: center;
`